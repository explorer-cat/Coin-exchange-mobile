import React, {useEffect, useState, useCallback} from 'react';
import { info } from 'console';
import { isJSDocDeprecatedTag } from 'typescript';
import "./Premium.css"

function Premium():React.ReactElement {
    return (
          <div className = "premium-view">
                    dfdfd
          </div>
    );
}

export default Premium;

