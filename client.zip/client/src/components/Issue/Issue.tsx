import React, {useEffect, useState, useCallback} from 'react';
import { info } from 'console';
import { isJSDocDeprecatedTag } from 'typescript';
import "./Issue.css"
import '../../stylesheets/initialization.css'
import '../../stylesheets/palette.css'

function Issue():React.ReactElement {
    return (
          <div className = "issue-view">
                    dfdfd
          </div>
    );
}

export default Issue;

